<script setup lang="ts"></script>

<template>
  <div class="bg-dark py-5">
    <div class="container">
      <div class="d-flex align-items-center justify-content-between text-white mb-md-7 mb-4">
        <img
          class="img-fluid"
          style="width: 3.75rem; height: 3.75rem"
          src="../assets/images/logo.webp"
          alt="logo"
        />
        <ul class="d-flex list-unstyled mb-0 h4">
          <li>
            <a href="#" class="text-white mx-3"><i class="fab fa-facebook"></i></a>
          </li>
          <li>
            <a href="#" class="text-white mx-3"><i class="fab fa-instagram"></i></a>
          </li>
          <li>
            <a href="#" class="text-white ms-3"><i class="fab fa-line"></i></a>
          </li>
        </ul>
      </div>
      <div
        class="d-flex flex-column flex-md-row justify-content-between align-items-md-end align-items-start text-white"
      >
        <div class="mb-md-0 mb-1">
          <p class="mb-0">02-3456-7890</p>
          <p class="mb-0">plantlife@mail.com</p>
        </div>
        <p class="mb-0">© 2025 植感生活 All Rights Reserved.</p>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
