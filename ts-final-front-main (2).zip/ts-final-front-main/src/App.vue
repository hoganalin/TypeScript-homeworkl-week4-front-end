<script setup lang="ts"></script>

<template>
  <RouterView />
</template>

<style lang="scss" scoped></style>
